# Formato dos arquivos

  - Linha 1: número de pessoas n
  - Linha 2: valores dispostos a pagar v1, v2, ..., vn
  - Linhas 2+i, i=1,...n: valores v_{i,i+1}, v_{i,i+2}, ..., v_{i,i+n}.
  - Linhas: 3+n, 4+n: ignorar
  - Linha 5+n: pesos das pessoa p1, p2, ..., pn
